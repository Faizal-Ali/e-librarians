@extends('layouts.app')
@section('content')
{{ csrf_field () }}
<div class="container" style="margin-top:20px;">
    <div>
        <div class="row">
                <div class="col-md-4">
                    <div class="card">
                    <div class="card-body">
                    <img src="{{asset('img/'.$data->gbr)}}" class="card-img-top" alt="">
                    </div>
                    </div> <br>
                    <div class="text-center">
                    @if (($data->status)==1)
                    <button type="submit" style="margin-left:25px;" class="btn btn-primary" onclick="confirm('Ingin Meminjam {{ $data->judul}} ?')" value="submit">Borrow Now</button>
                    @else
                    <button type="submit" class="btn btn-warning" style="margin-left:30px;" >Borrowed</button>
                     @endif
                     </div>
                </div>
                <div class="col-md-8">
                    <h1 class="text-center">{{$data->judul}}</h1>
                    <p>Pengarang : {{$data->pengarang}} <br>
                    Penerbit : {{$data->penerbit}} <br>
                    Tahun terbit : {{$data->terbit}} <br>
                    Kategori : {{$data->kategori}} <br>
                    Sinopsis : <br> {{$data->deskripsi}}                    
                    </p>
                   
                </div>
        </div>
    </div>
</div>
@stop