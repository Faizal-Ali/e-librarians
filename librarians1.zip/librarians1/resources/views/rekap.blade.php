@extends('layouts.app')
@section('content')
<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="col-md-4">
            <div class="card bg-warning">
                <p class="text-white">&nbsp Terpinjam</p>
                @if(($pinjam)==0)
                <h1 class="text-white text-center">0</h1>
                @else
                    
                    <h1 class="text-white text-center">{{$pinjam}}</h1>
                    @endif
            </div>
        </div>
        <div class="col-md-4">
        <div class="card bg-primary">
                <p class="text-white">&nbsp Dikembalikan :</p>
                @if(($kembali)==0)
                <h1 class="text-white text-center">0</h1>
                @else
                    <h1 class="text-white text-center">{{$kembali}}</h1>
                    @endif
            </div>
        </div>
        <div class="col-md-4">
        <div class="card bg-danger">
                <p class="text-white">&nbsp Jumlah Denda :</p>
                @if(($denda)==0)
                <h1 class="text-white text-center">0</h1>
                @else
                    
                    <h1 class="text-white text-center">Rp. {{$denda}}</h1>
                    @endif
            </div>
        </div>
    </div><br><br>
<!-- ===================================================================================== -->
    <div class="row">
        <div class="col-md-4">
            <div class="card bg-success">
                <p class="text-white">&nbsp Jumlah Buku :</p>
                @if(($buku)==0)
                <h1 class="text-white text-center">0</h1>
                @else
                    
                    <h1 class="text-white text-center">{{$buku}}</h1>
                    @endif
            </div>
        </div>
        <div class="col-md-4">
        <div class="card bg-success">
                <p class="text-white">&nbsp Jumlah Anggota :</p>
                @if(($anggota)==0)
                <h1 class="text-white text-center">0</h1>
                @else
                    <h1 class="text-white text-center">{{$anggota}}</h1>
                    @endif
            </div>
        </div>
        <div class="col-md-4">
        <div class="card bg-success">
                <p class="text-white">&nbsp Jumlah Pegawai :</p>
                @if(($admin)==0)
                <h1 class="text-white text-center">0</h1>
                @else
                    
                    <h1 class="text-white text-center">{{$admin}}</h1>
                    @endif
            </div>
        </div>
    </div>
</div>
@stop