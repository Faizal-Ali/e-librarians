@extends('layouts.app')
@section('content')
<div class="container">
<h1>Daftar Buku</h1>
<form class="form-inline">
<div class="mr-auto">
<a href="{{ route('register')}}" class="btn btn-success"><span class="fa fa-ok"></span> Tambah</a>
</div>
<div class="ml-auto">
        <input class="form-control col-lg-8" type="search" placeholder="Search" aria-label="Search">
        
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        </div>
        <br>
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Alamat</th>
                <th>No. Telp</th>
                <th>NIM</th>
                <th>Aksi</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            @foreach ($user as $data)
    <?php $no++;?>
            <tbody>
            <tr>
            <td>{{$no}}</td>
            <td>{{ $data->name }}</td>
            <td>{{ $data->email}}</td>
            <td>{{ $data->alamat }}</td>
            <td>{{ $data->notelp}}</td>
            <td>{{ $data->nim}}</td>
            <td>
            <form action="{{ route ('deleteu', $data->id)}}" method="post">
            <a href="{{ route ('updateu', $data)}}" class="btn btn-warning">Edit</a>
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger" onclick="confirm('Ingin Menghapus {{ $data->judul}} ?')">Hapus</button>
            <a href="{{ route ('redeem', $data)}}" class="btn btn-primary">Redeem</a>
            <a href="{{ route ('denda', $data)}}" class="btn btn-primary">Denda</a>
            </form>
            </td>
        </tr>          
            </tbody>
            @endforeach
        </table>
</div>
@stop