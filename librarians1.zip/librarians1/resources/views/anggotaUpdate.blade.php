@extends('layouts.app')
@section('content')
<div class="container">
<form action="{{ route ('editu', $data)}}" method="post">
<div class="card-head">
<h1>Tambah Buku</h1>
</div>

<div class="card-body">
<div class="form-group ">
{{ csrf_field () }}
<div class="form-group row">
    <label for="nama" class="col-md-4 col-form-label text-md-right">Nama</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="nama" value="{{ $data->name}}" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="email" class="col-md-4 col-form-label text-md-right">email</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="email" value="{{ $data->email}}" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="notelp" class="col-md-4 col-form-label text-md-right">No. Telepon</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="notelp" value="{{ $data->notelp}}" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="alamat" class="col-md-4 col-form-label text-md-right">Alamat</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="alamat" value="{{ $data->alamat}}" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="nim" class="col-md-4 col-form-label text-md-right">NIM</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="nim" value="{{ $data->nim}}" required autofocus>
        </div>
</div>
    <br>
    <div class="col-lg-6 ml-auto">
    <input type="submit" class="btn btn-primary" value="submit">
    </div>
</form>
</div>
</div>
@stop