@extends('layouts.app')
@section('content')
<div class="container">
<h1>Daftar Buku</h1>
<form class="form-inline">
<div class="mr-auto">
<a href="{{ url('/tambah_buku')}}" class="btn btn-success"><span class="fa fa-ok"></span> Tambah</a>
</div>
<div class="ml-auto">
        <input class="form-control col-lg-8" type="search" placeholder="Search" aria-label="Search">
        
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        </div>
        <br>
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Id Buku</th>
                <th>Judul</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Tempo</th>
                <th>Aksi</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            @foreach ($buku as $data)
    <?php $no++;?>
            <tbody>
            <tr>
            <td>{{$no}}</td>
            <td>{{ $data->nama_user }}</td>
            <td>{{ $data->id_buku }}</td>
            <td>{{ $data->judul }}</td>
            <td>{{ $data->tanggal_pinjam }}</td>
            <td>{{ $data->max_kembali }}</td>
            <td>
            <form action="{{ route('kembali',$data)}}" method="post" >
            @csrf
            
            <input type="hidden" name="max_kembali" value="{{ $data->max_kembali }}">
            <input type="hidden" name="id" value="{{ $data->id_user }}">
            <input type="hidden" name="buku" value="{{ $data->id_buku }}">
            <input type="hidden" name="nama" value="{{ $data->nama_user }}">
            <input type="hidden" name="pinjam" value="{{ $data->tanggal_pinjam }}">
            <input type="hidden" name="judul_buku" value="{{ $data->judul }}">
            @foreach ($denda13 as $denda1)
    <input type="hidden" class="form-control" name="dendax" value="{{$denda1->dendau}}">
@endforeach
@foreach ($point13 as $point1)
    <input type="number" class="form-control" name="pointx" value="{{$point1->point}}">
@endforeach
            <button type="submit" class="btn btn-warning">Kembali</button>
            </form>
            </td>
            <td>
           
            </td>
        </tr>          
            </tbody>
            @endforeach
        </table>
</div>
@stop