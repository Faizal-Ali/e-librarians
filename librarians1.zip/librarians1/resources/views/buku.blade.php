@extends('layouts.app')
@section('content')
<div class="container">
<h1>Daftar Buku</h1>
<form class="form-inline">
<div class="mr-auto">
<a href="{{ route('tambahB')}}" class="btn btn-success"><span class="fa fa-ok"></span> Tambah</a>
</div>
<div class="ml-auto">
        <input class="form-control col-lg-8" type="search" placeholder="Search" aria-label="Search">
        
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        </div>
        <br>
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Pengarang</th>
                <th>Terbit</th>
                <th>Kategori</th>
                <th>Kode</th>
                <th>Aksi</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            @foreach ($buku as $data)
    <?php $no++;?>
            <tbody>
            <tr>
            <td>{{$no}}</td>
            <td>{{ $data->judul }}</td>
            <td>{{ $data->pengarang }}</td>
            <td>{{ $data->terbit }}</td>
            <td>{{ $data->kategori }}</td>
            <td>{{ $data->kode }}</td>
            <td>
            <form action="{{ route ('delete', $data->id_buku)}}" method="post">
            <a href="{{ route ('update', $data)}}" onclick="return confirm('are you sure?')" class="btn btn-warning">Edit</a>
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger"  onclick="return confirm('are you sure?')">Hapus</button>
            
            </form>
            </td>
        </tr>          
            </tbody>
            @endforeach
        </table>
</div>
@stop