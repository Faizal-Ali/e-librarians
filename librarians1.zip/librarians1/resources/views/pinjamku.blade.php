@extends('layouts.app')
@section('content')
<div class="container"><br>
<h1>Daftar buku yang masih dipinjam</h1>
<form class="form-inline">

<div class="ml-auto">
        <input class="form-control col-lg-8" type="search" placeholder="Search" aria-label="Search">
        
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        </div>
        <br>
        
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Pengembalian</th><div class="mr-auto">
                <th>Status</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            @foreach ($buku as $data1)
    <?php $no++;?>
            <tbody>
            <tr>
            <td>{{$no}}</td>
            <td>{{ $data1->judul }}</td>
            <td>{{ $data1->tanggal_pinjam}}</td>
            <td>{{ $data1->max_kembali }}</td>
            <td>Belum Dikembalikan</td>
            <td>
            </td>
        </tr>          
            </tbody>
            @endforeach
        </table>
        <h1>Buku yang belum diambil</h1>

        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Pengembalian</th><div class="mr-auto">
                <th>Status</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            @foreach ($buku1 as $data2)
    <?php $no++;?>
            <tbody>
            <tr>
            <td>{{$no}}</td>
            <td>{{ $data2->judul }}</td>
            <td>{{ $data2->tanggal_pinjam }}</td>
            <td>{{ $data2->max_kembali }}</td>
            <td>Belum Diambil</td>
            <td>
            </td>
        </tr>          
            </tbody>
            @endforeach
        </table>
</div>
@stop