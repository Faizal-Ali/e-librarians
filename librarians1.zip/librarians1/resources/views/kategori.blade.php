@extends('layouts.app')
@section('content')
<div class="container">
<h1>Daftar Buku</h1>
<form class="form-inline">
<div class="mr-auto">
<a href="{{ url('/tambah_kategori')}}" class="btn btn-success"><span class="fa fa-ok"></span> Tambah</a>
</div>
<div class="ml-auto">
        <input class="form-control col-lg-8" type="search" placeholder="Search" aria-label="Search">
        
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        </div>
        <br>
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>

                <th>Kategori</th>
                <th>Aksi</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            @foreach ($kgi as $data)
    <?php $no++;?>
            <tbody>
            <tr>
            <td>{{$no}}</td>

            <td>{{ $data->kategori }}</td>
            <td>
            <form action="{{ route ('deleteK', $data->id_kategori)}}" method="post">
            <a href="{{ route ('update', $data)}}" class="btn btn-warning">Edit</a>
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger" onclick="confirm('Ingin Menghapus {{ $data->judul}} ?')">Hapus</button>
        
            </form>
            </td>
        </tr>          
            </tbody>
            @endforeach
        </table>
</div>
@stop