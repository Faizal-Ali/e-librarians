<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
<div class="">
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm sticky-top">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Laravel') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto col-md-10">
                    @guest
                            @if (Route::has('register'))

                            <form class="mx-2 mr-auto d-inline w-100">
                             <div class="input-group">
                                <input type="search" class="form-control" placeholder="Cari Buku favoritmu">
                                      <span class="input-group-append">
                                          <button class="btn btn-outline-primary" type="button">GO</button>&nbsp
                                       </span>
                             </div>
                        </form>
                            @endif
                            @else
                            @can('anggota')
                            <li class="nav-item">
                            <a href="{{ route('pinjamku')}}" class="nav-link">Daftar Pinjaman</a>
                            </li>

                            <li class="nav-item">
                          
                            <a href="" class="nav-link">|   Denda : Rp. {{ Auth::user()->denda }}</a>
                          
                            </li>
                            
                            <li class="nav-item">
                           <a href="" class="nav-link">Point : {{ Auth::user()->point }}   |</a>
                            
                            </li>
                            @endcan
                            @can('admin')
                            <li class="nav-item">
                            <a href="{{ url('/welcome')}}" class="nav-link">Katalog</a>
                            </li>
                            <li class="nav-item">
                            <a href="{{ url('sirkulasi')}}" class="nav-link">Sirkulasi</a>
                            </li>
                            <li class="nav-item">
                            <a href="{{ url('waitting_list')}}" class="nav-link">Waitting List</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>Master Data<span class="caret"></span>
                                </a>
                    
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a href="{{ url('/buku')}}" class="dropdown-item">Buku</a>
                                    <a href="{{ url('/daftar_anggota')}}" class="dropdown-item">Anggota</a>
                                    <a href="{{ url('/edit_denda')}}" class="dropdown-item">Denda</a>
                                    <a href="{{ url('/edit_max')}}" class="dropdown-item">Max Hari</a>
                                    <a href="{{ url('/kategori')}}" class="dropdown-item">Kategori</a>
                                    <a href="{{ url('/edit_point')}}" class="dropdown-item">Point</a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                            @endcan
                            @can('super')
                            <li class="nav-item">
                            <a href="{{ url('/welcome')}}" class="nav-link">Katalog</a>
                            </li>
                            <li class="nav-item">
                            <a href="{{ url('waitting_list')}}" class="nav-link">Waitting List</a>
                            </li>
                            <li class="nav-item">
                            <a href="{{ url('/sirkulasi')}}" class="nav-link">Sirkulasi</a>
                            </li>
                            <li><a href="/rekap" class="nav-link">Rekap</a></li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>Master Data<span class="caret"></span>
                                </a>
                    
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a href="{{ url('/buku')}}" class="dropdown-item">Buku</a>
                                    <a href="{{ url('/daftar_anggota')}}" class="dropdown-item">Anggota</a>
                                    <a href="{{ url('/edit_denda')}}" class="dropdown-item">Denda</a>
                                    <a href="{{ url('/edit_max')}}" class="dropdown-item">Max Hari</a>
                                    <a href="{{ url('/kategori')}}" class="dropdown-item">Kategori</a>
                                    <a href="{{ url('/edit_point')}}" class="dropdown-item">Point</a>
                                    <a href="{{ url('/edit_point')}}" class="dropdown-item">Rekap</a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                            @endcan
                            @endguest
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        @guest
                            @if (Route::has('register'))
                            @endif &nbsp 
                            &nbsp
                            <a href="{{ route('register')}}" class="btn btn-outline-success">Sign Up</a> &nbsp
                            <a href="{{ route('login')}}" class="btn btn-outline-primary">Login</a>
                           
                        @else

                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>
                    
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="">
            @yield('content')
        </main>
    </div>
    </div>
</body>
</html>
