<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Perpustakaan</title>
    <link href="{{asset('css/app.css')}}" rel="stylesheet">
    
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top navbar-light bg-white">
    <ul></ul><ul></ul>
        <font face="cmmi10" size="4">Perpustakaan</font>
        &nbsp;
        <div class="">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon text-center"></span>
              </button>
            </div>
        <div class="collapse navbar-collapse" id="menu">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">

                </ul>
              
<button class="btn btn-primary" data-toggle="modal" data-target="#login">Login</button> 
<div class="modal fade" id="login" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
     <div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
    </div>
<div class="modal-body">
                <form class="my-2 my-lg-0">
                    
                        <input class="form-control mr-sm-2" type="input" placeholder="Username">
                        <br>
                        <input class="form-control mr-sm-2" type="input" placeholder="Password">
                      </form>

</div>
    <div class="modal-footer">
    <button type="button" class="btn btn-primary m-t-10" data-dismiss="modal">Go..</button>
</div>
</div>
</div>
</div>
                      <ul></ul><ul></ul>
                    
                    </div>

        </nav>
        @yield('nav')
<script src="{{ asset('js/jquery.slim.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}" ></script>
<script src="{{ asset('js/bootstrap.min.js') }}" ></script>
</body>
</html> 