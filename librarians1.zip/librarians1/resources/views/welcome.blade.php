@extends('layouts.app')
<h1 class="text-center">kontol</h1>
<!-- @section('content')
<div class="">
<div class=" w-80">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100"  style="max-height:600px;" src="{{ asset('img/a1.jpg')}}" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" style="max-height:600px;" src="{{ asset('img/a2.jpg')}}" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" style="max-height:600px;" src="{{ asset('img/a3.jpg')}}" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
    </div>
    </div>
    <br>
<div class="bg-primary p-3 mb-2 text-white">
<div class="row">
  <div class="col-lg-10"><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium mollitia quasi inventore perferendis, </p></div>
  

</div>
</div>
</div>
</div>

<div class="container">
    <div class="text-center">
    <h1>Apa yang kamu cari ?</h1>
        <br><br>
        <form action="" class="form-inline justify-content-center">
        
        <input type="search" name="search" id="" class="col-md-5 form-control" value="">&nbsp
        <button type="submit" id="cari" name="cari" class="btn btn-primary"> Search</button>  
        
        </form>
    </div>
    <br>
    <div>
    <p><h1>Buku Terbaru</h1></p>
    <div class="card-deck">
    @foreach ($buku1 as $data1)
    <div class="card" style="width: 18rem;">
    <a href="{{ route('detail',$data1)}}" style="text-decoration:none;color:black;" >
  <img src="{{asset('img/'.$data1->gbr)}}" class="card-img-top" alt="..."  style="height:200px;">
  <div class="card-body">
    <h5 class="card-title">{{$data1 -> judul}}</h5>
    <p class="card-text">Pengarang : {{$data1 -> pengarang}} <br> Penerbit : {{$data1 -> terbit}} <br> Pengarang : {{$data1 -> kode}} <br>sinposis : {{str_limit($data1 -> deskripsi, $limit=50, $end='....')}}</p>
  </div>
  </a>
</div>
    @endforeach
    </div>  
    </div>
    </div><br><br>
    <div class="bg-primary text-light p-3">
Lorem ipsum, dolor sit amet consectetur adipisicing elit. Perspiciatis, placeat hic saepe cumque sed adipisci, vero quaerat iusto suscipit eaque doloremque quasi, earum illum laborum dolorum explicabo animi! Nisi, fugiat!
</div>
    <br>
    <div class="container">
    <p><h1>Buku Populer</h1></p>
    <div class="card-deck">
    @foreach ($buku as $data)
    <div class="card" style="width: 18rem;" >
    <a href="/" style="text-decoration:none;color:black;" >
    <img src="{{asset('img/'.$data->gbr)}}" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title">{{$data->judul}}</h5>
    <p class="card-text"  style="height:250px;">Pengarang : {{$data -> pengarang}} <br> Penerbit : {{$data -> terbit}} <br> Pengarang : {{$data -> kode}} <br>sinposis : {{str_limit($data -> deskripsi, $limit=50, $end='....')}} </p>  
  </div>
  <div class="card-footer">
  <form action="{{ route('login')}}" method="post">
  @csrf

  <input type="hidden" name="buku" value="{{ $data->id_buku }}">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="{{ $data->judul }}">
    @if (($data->status)==1)
    <a href="{{ route('login')}}" class="btn btn-primary">Borrow</a>
    @else
    <button type="submit" class="btn btn-warning" disabled style="margin-left:30px;" >Borrowed</button>
    @endif
    

    </form> 
  </div>
  </a>
</div>

    @endforeach
    </div>    
    {{ $buku->links() }}
</div>
<br>
<div class="container">
    <p><h1>Sejarah</h1></p>
    <div class="card-deck">
    @foreach ($buku as $data)
    <div class="card" style="width: 18rem;" >
    <a href="/" style="text-decoration:none;color:black;" >
    <img src="{{asset('img/'.$data->gbr)}}" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title">{{$data->judul}}</h5>
    <p class="card-text"  style="height:250px;">Pengarang : {{$data -> pengarang}} <br> Penerbit : {{$data -> terbit}} <br> Pengarang : {{$data -> kode}} <br>sinposis : {{str_limit($data -> deskripsi, $limit=50, $end='....')}} </p>  
  </div>
  <div class="card-footer">
  <form action="{{ route('login')}}" method="post">
  @csrf

  <input type="hidden" name="buku" value="{{ $data->id_buku }}">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="{{ $data->judul }}">
    @if (($data->status)==1)
    <a href="{{ route('login')}}" class="btn btn-primary">Borrow</a>
    @else
    <button type="submit" class="btn btn-warning" disabled style="margin-left:30px;" >Borrowed</button>
    @endif
    

    </form> 
  </div>
  </a>
</div>

    @endforeach
    </div>    
    {{ $buku->links() }}
</div>

<br>
<div class="container">
    <p><h1>Kamus</h1></p>
    <div class="card-deck">
    @foreach ($buku as $data)
    <div class="card" style="width: 18rem;" >
    <a href="/" style="text-decoration:none;color:black;" >
    <img src="{{asset('img/'.$data->gbr)}}" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title">{{$data->judul}}</h5>
    <p class="card-text"  style="height:250px;">Pengarang : {{$data -> pengarang}} <br> Penerbit : {{$data -> terbit}} <br> Pengarang : {{$data -> kode}} <br>sinposis : {{str_limit($data -> deskripsi, $limit=50, $end='....')}} </p>  
  </div>
  <div class="card-footer">
  <form action="{{ route('login')}}" method="post">
  @csrf
 
  <input type="hidden" name="buku" value="{{ $data->id_buku }}">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="{{ $data->judul }}">
    @if (($data->status)==1)
    <a href="{{ route('login')}}" class="btn btn-primary">Borrow</a>
    @else
    <button type="submit" class="btn btn-warning" disabled style="margin-left:30px;" >Borrowed</button>
    @endif
    

    </form> 
  </div>
  </a>
</div>

    @endforeach
    </div>    
    {{ $buku->links() }}
</div>

<br>
    <div class="container">
    <p><h1>Ensiklopedia</h1></p>
    <div class="card-deck">
    @foreach ($buku as $data)
    <div class="card" style="width: 18rem;" >
    <a href="/" style="text-decoration:none;color:black;" >
    <img src="{{asset('img/'.$data->gbr)}}" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title">{{$data->judul}}</h5>
    <p class="card-text"  style="height:250px;">Pengarang : {{$data -> pengarang}} <br> Penerbit : {{$data -> terbit}} <br> Pengarang : {{$data -> kode}} <br>sinposis : {{str_limit($data -> deskripsi, $limit=50, $end='....')}} </p>  
  </div>
  <div class="card-footer">
  <form action="{{ route('login')}}" method="post">
  @csrf

  <input type="hidden" name="buku" value="{{ $data->id_buku }}">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="{{ $data->judul }}">
    @if (($data->status)==1)
   <a href="{{ route('login')}}" class="btn btn-primary">Borrow</a>
    @else
    <button type="submit" class="btn btn-warning" disabled style="margin-left:30px;" >Borrowed</button>
    @endif
    

    </form> 
  </div>
  </a>
</div>

    @endforeach
    </div>    
    {{ $buku->links() }}
</div>
<br><br>

<br><br>
<div class="bg-dark p-1 text-white">
<p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis magnam, dignissimos qui doloribus eius in inventore omnis! Cum nulla inventore voluptatem impedit fugit. Libero cum quo sint, eligendi debitis dolor?</p>
</div>
@stop -->
