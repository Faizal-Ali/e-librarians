<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::any('/lol', 'KategoriController@All')->name('all');
Route::get('/', 'BukuController@welcome');
Route::get('/detail/{buku}', 'BukuController@detail')->name('detail');
// ----------------------------------------------------------
Route::get('/welcome', 'BukuController@login');
Route::get('/buku', 'BukuController@buku');
Route::get('/buku_baru', 'BukuController@kategori')->name('tambahB');
Route::delete('/{buku}/delete','BukuController@delete')->name('delete');
Route::get('/buku/update_buku/{buku}','BukuController@update')->name('update');
Route::get('/edit_point','BukuController@edit_point')->name('editp');
Route::post('/update_point/{point}','BukuController@update_point')->name('updatep');
Route::post('/buku/edit/{buku}','BukuController@edit')->name('edit');
Route::any('/tambah_buku','BukuController@insert')->name('insert');
Auth::routes();
// Route::get('/admin', 'BukuController@indexAdmin');
Route::get('/sirkulasi', 'BukuController@sirkulasi')->name('sirkulasi');
Route::get('/edit_denda', 'BukuController@edit_denda')->name('dendax');
Route::get('/edit_max', 'BukuController@edit_max')->name('maxu');
Route::post('/max_update/{max}','BukuController@update_max')->name('maxp');
Route::post('/denda_update/{denda1}','BukuController@update_denda')->name('dendau');
Route::get('/waitting_list', 'BukuController@wlist')->name('wlist');
Route::any('/ambil/{data}', 'BukuController@ambil')->name('ambil');
Route::any('/kembali/{data}', 'BukuController@pengembalian')->name('kembali');
// ----------------------------------------------------------
Route::get('/daftar_anggota', 'UserController@views');
Route::delete('/daftar_anggota/{id}/delete','UserController@delete')->name('deleteu');
Route::get('/daftar_anggota/update_anggota/{user}','UserController@update')->name('updateu');
Route::post('/daftar_anggota/edit/{user}','UserController@edit')->name('editu');
// --------------------------------------------------------------
Route::post('/pinjam/{data}','BukuController@pinjam')->name('peminjaman');
Route::get('/pinjamku','BukuController@pinjamku')->name('pinjamku');
Route::get('/redeem/{user}','BukuController@redeem')->name('redeem');
Route::get('/denda/{user}','BukuController@denda')->name('denda');
Route::post('/tukar/{user}','BukuController@tukar')->name('tukar');
Route::post('/tax/{user}','BukuController@tax')->name('tax');
// --------------------------------------------------------------
Route::get('/daftar_buku',function(){
    return view('buku');
});

Route::get('/tambah_kategori',function(){
    return view('kategoriTambah');
});
////////////////////////////////////////////////////////////////////////////////
Route::post('/insert_kategori','KategoriController@insert')->name('insertK');
Route::get('/kategori', 'KategoriController@show')->name('show');
Route::delete('/kategori_delete/{data}', 'KategoriController@delete')->name('deleteK');
//--------------------------------------------------------------------------------
Route::get('/rekap', 'KategoriController@rekap');
