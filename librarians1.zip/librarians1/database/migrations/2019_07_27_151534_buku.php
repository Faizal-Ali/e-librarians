<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Buku extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('buku', function (Blueprint $table) {
            $table->bigIncrements('id_buku')->unique();
            $table->string('judul');
            $table->string('pengarang');
            $table->string('kategori');
            $table->string('terbit');
            $table->string('kode');
            $table->timestamp('created_at')->nullable();
        });
    }
    public function article(){
    	return $this->hasMany('App\Kategori');
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
