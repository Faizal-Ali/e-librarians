<?php $__env->startSection('content'); ?>
<div class="container"><br>
<h1>Daftar buku yang masih dipinjam</h1>
<form class="form-inline">

<div class="ml-auto">
        <input class="form-control col-lg-8" type="search" placeholder="Search" aria-label="Search">
        
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        </div>
        <br>
        
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Pengembalian</th><div class="mr-auto">
                <th>Status</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $no++;?>
            <tbody>
            <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($data1->judul); ?></td>
            <td><?php echo e($data1->tanggal_pinjam); ?></td>
            <td><?php echo e($data1->max_kembali); ?></td>
            <td>Belum Dikembalikan</td>
            <td>
            </td>
        </tr>          
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <h1>Buku yang belum diambil</h1>

        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Pengembalian</th><div class="mr-auto">
                <th>Status</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            <?php $__currentLoopData = $buku1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $no++;?>
            <tbody>
            <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($data2->judul); ?></td>
            <td><?php echo e($data2->tanggal_pinjam); ?></td>
            <td><?php echo e($data2->max_kembali); ?></td>
            <td>Belum Diambil</td>
            <td>
            </td>
        </tr>          
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/librarians/resources/views/pinjamku.blade.php ENDPATH**/ ?>