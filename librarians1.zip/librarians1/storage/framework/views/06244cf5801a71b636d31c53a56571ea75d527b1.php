<?php $__env->startSection('content'); ?>
<div class="">
<div class=" w-80">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100"  style="max-height:600px;" src="<?php echo e(asset('img/a1.jpg')); ?>" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" style="max-height:600px;" src="<?php echo e(asset('img/a2.jpg')); ?>" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" style="max-height:600px;" src="<?php echo e(asset('img/a3.jpg')); ?>" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
    </div>
    </div>
    <br>
<div class="bg-primary p-3 mb-2 text-white">
<div class="row">
  <div class="col-lg-10"><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium mollitia quasi inventore perferendis, </p></div>
  

</div>
</div>
</div>
</div>

<div class="container">
    <div class="text-center">
    <h1>Apa yang kamu cari ?</h1>
        <br><br>
        <form action="" class="form-inline justify-content-center">
        
        <input type="search" name="search" id="" class="col-md-5 form-control" value="">&nbsp
        <button type="submit" id="cari" name="cari" class="btn btn-primary"> Search</button>  
        
        </form>
    </div>
    <br>
    <div class="text-center">
        <button class="btn btn-primary">Horor</button>
        <button class="btn btn-success">Sejarah</button>
        <button class="btn btn-danger">Ensiklopedia</button>
        <button class="btn btn-warning">Biografi</button>
        <button class="btn btn-info">Kamus</button>
        <button class="btn btn-primary">Horor</button>
        <button class="btn btn-success">Sejarah</button><br><br>
        <button class="btn btn-danger">Ensiklopedia</button>
        <button class="btn btn-warning">Biografi</button>
        <button class="btn btn-info">Kamus</button>        <button class="btn btn-primary">Horor</button>
        <button class="btn btn-success">Sejarah</button>
        <button class="btn btn-danger">Ensiklopedia</button>
        <button class="btn btn-warning">Biografi</button>
        <button class="btn btn-info">Kamus</button>        <button class="btn btn-primary">Horor</button>
        <button class="btn btn-success">Sejarah</button>
        <button class="btn btn-danger">Ensiklopedia</button>
        <button class="btn btn-warning">Biografi</button><br><br>
    </div>
    <div>
    <p><h1>Buku Terbaru</h1></p>
    <div class="card-deck">
    <?php $__currentLoopData = $buku1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="width: 18rem;">
    <a href="<?php echo e(route('detail',$data1)); ?>" style="text-decoration:none;color:black;" >
  <img src="<?php echo e(asset('img/'.$data1->gbr)); ?>" class="card-img-top" alt="..."  style="height:200px;">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($data1 -> judul); ?></h5>
    <p class="card-text">Pengarang : <?php echo e($data1 -> pengarang); ?> <br> Penerbit : <?php echo e($data1 -> terbit); ?> <br> Pengarang : <?php echo e($data1 -> kode); ?> <br>sinposis : <?php echo e(str_limit($data1 -> deskripsi, $limit=50, $end='....')); ?></p>
  </div>
  </a>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>  
    </div>
    </div><br><br>
    <div class="bg-primary text-light p-3">
Lorem ipsum, dolor sit amet consectetur adipisicing elit. Perspiciatis, placeat hic saepe cumque sed adipisci, vero quaerat iusto suscipit eaque doloremque quasi, earum illum laborum dolorum explicabo animi! Nisi, fugiat!
</div>
    <br>
    <div class="container">
    <p><h1>Buku Populer</h1></p>
    <div class="card-deck">
    <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="width: 18rem;" >
    <a href="/" style="text-decoration:none;color:black;" >
    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title"><?php echo e($data->judul); ?></h5>
    <p class="card-text"  style="height:250px;">Pengarang : <?php echo e($data -> pengarang); ?> <br> Penerbit : <?php echo e($data -> terbit); ?> <br> Pengarang : <?php echo e($data -> kode); ?> <br>sinposis : <?php echo e(str_limit($data -> deskripsi, $limit=50, $end='....')); ?> </p>  
  </div>
  <div class="card-footer">
  <form action="<?php echo e(route('login')); ?>" method="post">
  <?php echo csrf_field(); ?>

  <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="<?php echo e($data->judul); ?>">
    <?php if(($data->status)==1): ?>
    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Borrow</a>
    <?php else: ?>
    <button type="submit" class="btn btn-warning" disabled style="margin-left:30px;" >Borrowed</button>
    <?php endif; ?>
    

    </form> 
  </div>
  </a>
</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>    
    <?php echo e($buku->links()); ?>

</div>
<br>
<div class="container">
    <p><h1>Sejarah</h1></p>
    <div class="card-deck">
    <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="width: 18rem;" >
    <a href="/" style="text-decoration:none;color:black;" >
    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title"><?php echo e($data->judul); ?></h5>
    <p class="card-text"  style="height:250px;">Pengarang : <?php echo e($data -> pengarang); ?> <br> Penerbit : <?php echo e($data -> terbit); ?> <br> Pengarang : <?php echo e($data -> kode); ?> <br>sinposis : <?php echo e(str_limit($data -> deskripsi, $limit=50, $end='....')); ?> </p>  
  </div>
  <div class="card-footer">
  <form action="<?php echo e(route('login')); ?>" method="post">
  <?php echo csrf_field(); ?>

  <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="<?php echo e($data->judul); ?>">
    <?php if(($data->status)==1): ?>
    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Borrow</a>
    <?php else: ?>
    <button type="submit" class="btn btn-warning" disabled style="margin-left:30px;" >Borrowed</button>
    <?php endif; ?>
    

    </form> 
  </div>
  </a>
</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>    
    <?php echo e($buku->links()); ?>

</div>

<br>
<div class="container">
    <p><h1>Kamus</h1></p>
    <div class="card-deck">
    <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="width: 18rem;" >
    <a href="/" style="text-decoration:none;color:black;" >
    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title"><?php echo e($data->judul); ?></h5>
    <p class="card-text"  style="height:250px;">Pengarang : <?php echo e($data -> pengarang); ?> <br> Penerbit : <?php echo e($data -> terbit); ?> <br> Pengarang : <?php echo e($data -> kode); ?> <br>sinposis : <?php echo e(str_limit($data -> deskripsi, $limit=50, $end='....')); ?> </p>  
  </div>
  <div class="card-footer">
  <form action="<?php echo e(route('login')); ?>" method="post">
  <?php echo csrf_field(); ?>
 
  <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="<?php echo e($data->judul); ?>">
    <?php if(($data->status)==1): ?>
    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Borrow</a>
    <?php else: ?>
    <button type="submit" class="btn btn-warning" disabled style="margin-left:30px;" >Borrowed</button>
    <?php endif; ?>
    

    </form> 
  </div>
  </a>
</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>    
    <?php echo e($buku->links()); ?>

</div>

<br>
    <div class="container">
    <p><h1>Ensiklopedia</h1></p>
    <div class="card-deck">
    <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="width: 18rem;" >
    <a href="/" style="text-decoration:none;color:black;" >
    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title"><?php echo e($data->judul); ?></h5>
    <p class="card-text"  style="height:250px;">Pengarang : <?php echo e($data -> pengarang); ?> <br> Penerbit : <?php echo e($data -> terbit); ?> <br> Pengarang : <?php echo e($data -> kode); ?> <br>sinposis : <?php echo e(str_limit($data -> deskripsi, $limit=50, $end='....')); ?> </p>  
  </div>
  <div class="card-footer">
  <form action="<?php echo e(route('login')); ?>" method="post">
  <?php echo csrf_field(); ?>

  <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="<?php echo e($data->judul); ?>">
    <?php if(($data->status)==1): ?>
   <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Borrow</a>
    <?php else: ?>
    <button type="submit" class="btn btn-warning" disabled style="margin-left:30px;" >Borrowed</button>
    <?php endif; ?>
    

    </form> 
  </div>
  </a>
</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>    
    <?php echo e($buku->links()); ?>

</div>
<br><br>

<br><br>
<div class="bg-dark p-1 text-white">
<p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis magnam, dignissimos qui doloribus eius in inventore omnis! Cum nulla inventore voluptatem impedit fugit. Libero cum quo sint, eligendi debitis dolor?</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/perpustakaan/resources/views/welcome.blade.php ENDPATH**/ ?>