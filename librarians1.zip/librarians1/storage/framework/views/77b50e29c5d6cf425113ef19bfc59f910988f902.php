<?php $__env->startSection('content'); ?>
<?php echo e(csrf_field ()); ?>

<div class="container" style="margin-top:20px;">
    <div>
        <div class="row">
                <div class="col-md-4">
                    <div class="card">
                    <div class="card-body">
                    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="">
                    </div>
                    </div> <br>
                    <div class="text-center">
                    <?php if(($data->status)==1): ?>
                    <button type="submit" style="margin-left:25px;" class="btn btn-primary" onclick="confirm('Ingin Meminjam <?php echo e($data->judul); ?> ?')" value="submit">Borrow Now</button>
                    <?php else: ?>
                    <button type="submit" class="btn btn-warning" style="margin-left:30px;" >Borrowed</button>
                     <?php endif; ?>
                     </div>
                </div>
                <div class="col-md-8">
                    <h1 class="text-center"><?php echo e($data->judul); ?></h1>
                    <p>Pengarang : <?php echo e($data->pengarang); ?> <br>
                    Penerbit : <?php echo e($data->penerbit); ?> <br>
                    Tahun terbit : <?php echo e($data->terbit); ?> <br>
                    Kategori : <?php echo e($data->kategori); ?> <br>
                    Sinopsis : <br> <?php echo e($data->deskripsi); ?>                    
                    </p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Asperiores incidunt eaque aliquam voluptas veniam iste! Distinctio accusantium suscipit quia ipsa necessitatibus autem reiciendis commodi, officia officiis, inventore vero, eaque exercitationem! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos repellat labore ad rerum cum consectetur illo asperiores distinctio id, culpa voluptate ipsa eius, quo magni, enim esse eum molestias dolorum. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Inventore, hic. Id, fuga nobis eligendi, deserunt porro minima rem deleniti commodi dolorum suscipit incidunt quasi quia. Molestias dolorum voluptatibus officiis adipisci? Lorem ipsum, dolor sit amet consectetur adipisicing elit. Neque optio quo repellat! Hic quibusdam quis esse totam ad veniam maiores provident earum at. Quos ipsum quis laborum, cupiditate neque ea? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Saepe ratione modi quidem quod. Ad, vel eveniet. Illum similique tempora dignissimos, velit recusandae eligendi voluptatum, quas, cum eveniet soluta corporis perspiciatis! Lorem, ipsum dolor sit amet consectetur adipisicing elit. Fuga molestiae facere magni, atque quam alias ipsa sunt nam magnam, quos doloribus sit aliquam voluptatem consequuntur doloremque iste dolores ea laudantium. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Inventore voluptates molestiae minus quas quibusdam. Labore quis autem voluptas iusto cum eos, eaque animi necessitatibus dignissimos totam fugiat, eius quod inventore. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Natus pariatur quaerat, dolorum tempora explicabo aspernatur. Quibusdam placeat repellendus ipsum porro labore ea inventore eius, dolorem, nemo fuga odit iste voluptas. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eaque quidem eos id iusto! Nisi sit et voluptate minus distinctio eveniet, magnam nemo debitis aliquid id vel quas. Reiciendis, veniam aut! lore  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti, doloremque fuga porro aliquam id, odit tenetur nihil soluta natus assumenda ea tempora dolorem explicabo quo iste, quia enim quae quas? Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos, consectetur possimus harum praesentium quisquam excepturi perferendis ipsum blanditiis error deserunt dolorum maiores itaque tempore eligendi, quidem hic culpa ipsam cumque. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum a quam modi nesciunt reprehenderit molestiae explicabo tempore nihil? Ex commodi similique cumque obcaecati ratione neque in vero ducimus consectetur iste. Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam, doloribus maxime perferendis ea, blanditiis cupiditate nemo sapiente exercitationem molestiae ipsum, quo aliquid quidem reprehenderit quos nostrum veniam neque. Ex, facere. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem, ipsa expedita, quam quod sapiente deserunt, laudantium hic reprehenderit dolore natus consectetur? Deserunt facere fugit hic cupiditate ullam dolores doloremque sed. Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis rerum omnis corporis unde totam blanditiis asperiores odio laboriosam rem consequuntur numquam libero odit possimus doloremque, nihil, dicta nobis esse officiis. Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore tempore eveniet dicta incidunt nemo, eligendi, officia fugit unde accusamus dolorum maiores. Voluptatum sequi at laudantium? Quas quibusdam incidunt nobis ipsam! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima aperiam, enim voluptates optio quisquam, molestias eaque qui assumenda porro accusantium quos ducimus inventore quis error laborum nulla natus quaerat maiores! Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis autem eaque quidem tempora numquam dolore nihil nemo perspiciatis earum voluptatem quod ratione blanditiis, praesentium neque consectetur, eveniet, fuga eligendi facere! lore Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda, itaque neque amet illo laudantium dolore vero odit tempore facilis totam, nemo ad ea dolorem quam eos voluptatem perspiciatis nostrum fuga.
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/perpustakaan3/resources/views/detail.blade.php ENDPATH**/ ?>