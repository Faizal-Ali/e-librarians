<?php $__env->startSection('content'); ?>
<div class="container-fluid" >

<div class="text-center">
        <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt=""><br><br>

        </div>
    <div class="row">
        <div class="col-lg-2">
        <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nulla saepe illo placeat culpa ex quasi earum veritatis quis. Sunt perspiciatis aliquam iste voluptate corrupti voluptates mollitia et ut deserunt fugit!
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet quia similique nemo eos cum, facere quos corrupti laborum fugit culpa assumenda facilis esse reiciendis quaerat odit magni vitae, minus pariatur!
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deserunt neque ducimus inventore voluptates deleniti, aperiam accusantium in facilis repudiandae libero ad esse animi ex eveniet perferendis unde adipisci distinctio temporibus.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque aut error, eius non incidunt expedita, numquam sunt accusamus soluta cum quas temporibus porro. Id omnis praesentium excepturi ipsa error exercitationem.
        </p>
        </div>

        <div class="col-lg-8">

        <form class="form-inline">
        <div class="dropdown-menu">
            <a href=>kategori</a>
        </div>
        <input class="form-control col-lg-9" type="search" placeholder="Search" aria-label="Search">
        &nbsp &nbsp &nbsp
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        <p>
            <br>
            <button type="submit" class="btn btn-outline-info">Novel</button>
            <button type="submit" class="btn btn-outline-primary">Cerpen</button>
            <button type="submit" class="btn btn-outline-danger">Majalan</button>
            <button type="submit" class="btn btn-outline-warning">Ensiklopedia</button>
            <button type="submit" class="btn btn-outline-success">Kamus</button>
            <button type="submit" class="btn btn-outline-info">Biografi</button>
            <div></div>
            <button type="submit" class="btn btn-outline-warning">Surat Kabar</button>
            <button type="submit" class="btn btn-outline-danger">Analogi</button>
        </p>
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>Judul</th>
                <th>Pengarang</th>
                <th>Terbit</th>
                <th>Kode</th>
                <th>Aksi</th>
                </tr>
            </thead>
            <?php $no = 0; ?>
    <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $no++; ?>
            <tbody>
            <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($data->judul); ?></td>
            <td><?php echo e($data->pengarang); ?></td>
            <td><?php echo e($data->terbit); ?></td>
            <td><?php echo e($data->kode); ?></td>
            <td>
<a href="">Pinjam</a>
            </td>
        </tr>          
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>

        <div class="col-lg-2">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam in, sint harum ipsa vitae soluta nam consequatur dicta culpa reiciendis dolorem, labore commodi. Quas ullam explicabo neque inventore, sit veritatis?
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos magnam ab saepe velit repellendus quis exercitationem quasi inventore repellat odio, est doloremque odit reprehenderit, ea iste minima animi et aliquam.
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Minima maiores consequuntur quasi eius expedita fugiat veritatis officiis accusantium tempore, vero ullam dolorem maxime officia voluptatum, fugit eaque numquam optio molestiae.
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Amet debitis saepe quo numquam magnam dolorem, quas iusto ipsa, temporibus molestias molestiae quia accusamus officiis maiores, sed a tempora autem eos?
        </p>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/perpustakaan/resources/views//index.blade.php ENDPATH**/ ?>