<?php $__env->startSection('content'); ?>
<?php echo e(csrf_field ()); ?>

<div class="container" style="margin-top:20px;">
    <div>
        <div class="row">
                <div class="col-md-4">
                    <div class="card">
                    <div class="card-body">
                    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="">
                    </div>
                    </div> <br>
                    <div class="text-center">
                    <?php if(($data->status)==1): ?>
                    <button type="submit" style="margin-left:25px;" class="btn btn-primary" onclick="confirm('Ingin Meminjam <?php echo e($data->judul); ?> ?')" value="submit">Borrow Now</button>
                    <?php else: ?>
                    <button type="submit" class="btn btn-warning" style="margin-left:30px;" >Borrowed</button>
                     <?php endif; ?>
                     </div>
                </div>
                <div class="col-md-8">
                    <h1 class="text-center"><?php echo e($data->judul); ?></h1>
                    <p>Pengarang : <?php echo e($data->pengarang); ?> <br>
                    Penerbit : <?php echo e($data->penerbit); ?> <br>
                    Tahun terbit : <?php echo e($data->terbit); ?> <br>
                    Kategori : <?php echo e($data->kategori); ?> <br>
                    Sinopsis : <br> <?php echo e($data->deskripsi); ?>                    
                    </p>
                   
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/librarians/resources/views/detail.blade.php ENDPATH**/ ?>