<?php $__env->startSection('content'); ?>
<div class="container">
<h1>Daftar Buku</h1>
<form class="form-inline">
<div class="mr-auto">
<a href="<?php echo e(url('/tambah_buku')); ?>" class="btn btn-success"><span class="fa fa-ok"></span> Tambah</a>
</div>
<div class="ml-auto">
        <input class="form-control col-lg-8" type="search" placeholder="Search" aria-label="Search">
        
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        </div>
        <br>
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Id Buku</th>
                <th>Judul</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Tempo</th>
                <th>Aksi</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $no++;?>
            <tbody>
            <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($data->nama_user); ?></td>
            <td><?php echo e($data->id_buku); ?></td>
            <td><?php echo e($data->judul); ?></td>
            <td><?php echo e($data->tanggal_pinjam); ?></td>
            <td><?php echo e($data->max_kembali); ?></td>
            <td>
            <form action="<?php echo e(route('ambil',$data)); ?>" method="post" >
            <?php echo csrf_field(); ?>
            
            <input type="hidden" name="max_kembali" value="<?php echo e($data->max_kembali); ?>">
            <input type="hidden" name="id" value="<?php echo e($data->id_user); ?>">
            <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
            <input type="hidden" name="nama" value="<?php echo e($data->nama_user); ?>">
            <input type="hidden" name="pinjam" value="<?php echo e($data->tanggal_pinjam); ?>">
            <input type="hidden" name="judul_buku" value="<?php echo e($data->judul); ?>">
            <input type="hidden" name="kode" value="<?php echo e($data->kode_buku); ?>">
            <?php $__currentLoopData = $max14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $max1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden"  name="jth" value="<?php echo e($max1->max); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit" class="btn btn-warning">Diambil</button>
            </form>
            </td>
            <td>

            </td>
        </tr>          
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/perpustakaan3/resources/views/waitting.blade.php ENDPATH**/ ?>