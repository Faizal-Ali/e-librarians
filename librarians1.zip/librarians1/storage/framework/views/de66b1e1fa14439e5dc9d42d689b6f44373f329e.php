<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="col-md-4">
            <div class="card bg-warning">
                <p class="text-white">&nbsp Terpinjam</p>
                <?php if(($pinjam)==0): ?>
                <h1 class="text-white text-center">0</h1>
                <?php else: ?>
                    
                    <h1 class="text-white text-center"><?php echo e($pinjam); ?></h1>
                    <?php endif; ?>
            </div>
        </div>
        <div class="col-md-4">
        <div class="card bg-primary">
                <p class="text-white">&nbsp Dikembalikan :</p>
                <?php if(($kembali)==0): ?>
                <h1 class="text-white text-center">0</h1>
                <?php else: ?>
                    <h1 class="text-white text-center"><?php echo e($kembali); ?></h1>
                    <?php endif; ?>
            </div>
        </div>
        <div class="col-md-4">
        <div class="card bg-danger">
                <p class="text-white">&nbsp Jumlah Denda :</p>
                <?php if(($denda)==0): ?>
                <h1 class="text-white text-center">0</h1>
                <?php else: ?>
                    
                    <h1 class="text-white text-center">Rp. <?php echo e($denda); ?></h1>
                    <?php endif; ?>
            </div>
        </div>
    </div><br><br>
<!-- ===================================================================================== -->
    <div class="row">
        <div class="col-md-4">
            <div class="card bg-success">
                <p class="text-white">&nbsp Jumlah Buku :</p>
                <?php if(($buku)==0): ?>
                <h1 class="text-white text-center">0</h1>
                <?php else: ?>
                    
                    <h1 class="text-white text-center"><?php echo e($buku); ?></h1>
                    <?php endif; ?>
            </div>
        </div>
        <div class="col-md-4">
        <div class="card bg-success">
                <p class="text-white">&nbsp Jumlah Anggota :</p>
                <?php if(($anggota)==0): ?>
                <h1 class="text-white text-center">0</h1>
                <?php else: ?>
                    <h1 class="text-white text-center"><?php echo e($anggota); ?></h1>
                    <?php endif; ?>
            </div>
        </div>
        <div class="col-md-4">
        <div class="card bg-success">
                <p class="text-white">&nbsp Jumlah Pegawai :</p>
                <?php if(($admin)==0): ?>
                <h1 class="text-white text-center">0</h1>
                <?php else: ?>
                    
                    <h1 class="text-white text-center"><?php echo e($admin); ?></h1>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/librarians/resources/views/rekap.blade.php ENDPATH**/ ?>