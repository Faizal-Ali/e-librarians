<?php $__env->startSection('content'); ?>
<div class="container">
<h1>Daftar Buku</h1>
<form class="form-inline">
<div class="mr-auto">
<a href="<?php echo e(url('/buku_baru')); ?>" class="btn btn-success"><span class="fa fa-ok"></span> Tambah</a>
</div>
<div class="ml-auto">
        <input class="form-control col-lg-8" type="search" placeholder="Search" aria-label="Search">
        
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        </div>
        <br>
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Pengarang</th>
                <th>Terbit</th>
                <th>Kategori</th>
                <th>Kode</th>
                <th>Aksi</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $no++;?>
            <tbody>
            <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($data->judul); ?></td>
            <td><?php echo e($data->pengarang); ?></td>
            <td><?php echo e($data->terbit); ?></td>
            <td><?php echo e($data->kategori); ?></td>
            <td><?php echo e($data->kode); ?></td>
            <td>
            <form action="<?php echo e(route ('delete', $data->id_buku)); ?>" method="post">
            <a href="<?php echo e(route ('update', $data)); ?>" class="btn btn-warning">Edit</a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="confirm('Ingin Menghapus <?php echo e($data->judul); ?> ?')">Hapus</button>
            
            </form>
            </td>
        </tr>          
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/perpustakaan/resources/views/buku.blade.php ENDPATH**/ ?>