<?php $__env->startSection('content'); ?>
<div class="container">
<form action="<?php echo e(route ('editu', $data)); ?>" method="post">
<div class="card-head">
<h1>Tambah Buku</h1>
</div>

<div class="card-body">
<div class="form-group ">
<?php echo e(csrf_field ()); ?>

<div class="form-group row">
    <label for="nama" class="col-md-4 col-form-label text-md-right">Nama</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="nama" value="<?php echo e($data->name); ?>" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="email" class="col-md-4 col-form-label text-md-right">email</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="email" value="<?php echo e($data->email); ?>" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="notelp" class="col-md-4 col-form-label text-md-right">No. Telepon</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="notelp" value="<?php echo e($data->notelp); ?>" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="alamat" class="col-md-4 col-form-label text-md-right">Alamat</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="alamat" value="<?php echo e($data->alamat); ?>" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="nim" class="col-md-4 col-form-label text-md-right">NIM</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="nim" value="<?php echo e($data->nim); ?>" required autofocus>
        </div>
</div>
    <br>
    <div class="col-lg-6 ml-auto">
    <input type="submit" class="btn btn-primary" value="submit">
    </div>
</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/perpustakaan3/resources/views/anggotaUpdate.blade.php ENDPATH**/ ?>