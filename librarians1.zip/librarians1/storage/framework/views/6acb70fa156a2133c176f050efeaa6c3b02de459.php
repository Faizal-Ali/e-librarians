<?php $__env->startSection('content'); ?>
<div class="container">
<h1>Daftar Buku</h1>
<form class="form-inline">
<div class="mr-auto">
<a href="<?php echo e(route('register')); ?>" class="btn btn-success"><span class="fa fa-ok"></span> Tambah</a>
</div>
<div class="ml-auto">
        <input class="form-control col-lg-8" type="search" placeholder="Search" aria-label="Search">
        
        <button class="btn btn-outline-primary " type="submit">Search</button>
        </form>
        </div>
        <br>
        <table class="table table-stripped">
            <thead>
                <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Alamat</th>
                <th>No. Telp</th>
                <th>NIM</th>
                <th>Aksi</th>
                </tr>
            </thead>
            <?php $no = 0;?>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $no++;?>
            <tbody>
            <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e($data->alamat); ?></td>
            <td><?php echo e($data->notelp); ?></td>
            <td><?php echo e($data->nim); ?></td>
            <td>
            <form action="<?php echo e(route ('deleteu', $data->id)); ?>" method="post">
            <a href="<?php echo e(route ('updateu', $data)); ?>" class="btn btn-warning">Edit</a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="confirm('Ingin Menghapus <?php echo e($data->judul); ?> ?')">Hapus</button>
            <a href="<?php echo e(route ('redeem', $data)); ?>" class="btn btn-primary">Redeem</a>
            <a href="<?php echo e(route ('denda', $data)); ?>" class="btn btn-primary">Denda</a>
            </form>
            </td>
        </tr>          
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/perpustakaan/resources/views/anggota.blade.php ENDPATH**/ ?>