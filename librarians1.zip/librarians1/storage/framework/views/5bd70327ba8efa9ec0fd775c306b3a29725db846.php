<?php $__env->startSection('content'); ?>
<div class="">
<div class=" w-80">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100"  style="max-height:600px;" src="<?php echo e(asset('img/a1.jpg')); ?>" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" style="max-height:600px;" src="<?php echo e(asset('img/a2.jpg')); ?>" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" style="max-height:600px;" src="<?php echo e(asset('img/a3.jpg')); ?>" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
    </div>
    </div>
    <br>
<div class="bg-primary p-3 mb-2 text-white">
<div class="row">
  <div class="col-lg-10"><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium mollitia quasi inventore perferendis, </p></div>
  

</div>
</div>
</div>
</div>

<div class="container">
    <div class="text-center">
    <h1>Apa yang kamu cari ?</h1>
        <br><br>
        <form action="" class="form-inline justify-content-center">
        
        <input type="search" name="search" id="" class="col-md-5 form-control text-primary" value="">&nbsp
        <button type="submit" id="cari" name="cari" class="btn btn-primary" > Search</button>  
        
        </form>
    </div>
    </div>
    <br>
<br><br>
<div class="container">
    <p><h1>Buku Terbaru</h1></p>
    <div class="row">
    
    <?php $__currentLoopData = $baru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3">
    <div class="card"  >
    <a href="<?php echo e(route('detail',$data)); ?>" style="text-decoration:none;color:black;" >
    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title"><?php echo e($data->judul); ?></h5>
    <p class="card-text"  style="height:250px;">Pengarang : <?php echo e($data -> pengarang); ?> <br> Penerbit : <?php echo e($data -> terbit); ?> <br> Pengarang : <?php echo e($data -> kode); ?> <br>sinposis : <?php echo e(str_limit($data -> deskripsi, $limit=100, $end='....')); ?> </p>  
  </div>
  <div class="card-footer">
  <form action="<?php echo e(route('peminjaman', $data)); ?>" method="post">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="nama" value="<?php echo e(Auth::user()->name); ?>">
  <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
  <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="<?php echo e($data->judul); ?>">
    <?php if(($data->status)==1): ?>
    <button type="submit" style="margin-left:25px;" onclick="confirm('Ingin Meminjam <?php echo e($data->judul); ?> ?')" class="btn btn-primary" value="submit">Borrow Now</button>
    <?php else: ?>
    <button type="submit" class="btn btn-warning" style="margin-left:30px;" >Borrowed</button>
    <?php endif; ?>
    <?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denda1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="denda" value="<?php echo e($denda1->denda); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $max; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $max1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="max" value="<?php echo e($max1->max); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </form> 
  </div>
  </a>
</div>   </div>    

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
 </div>
</div><br><br>
    <div class="bg-primary text-light p-3">
Lorem ipsum, dolor sit amet consectetur adipisicing elit. Perspiciatis, placeat hic saepe cumque sed adipisci, vero quaerat iusto suscipit eaque doloremque quasi, earum illum laborum dolorum explicabo animi! Nisi, fugiat!
</div>
    <br>
    <div class="container">
    <p><h1>Novel</h1></p>
    <div class="row">
  
    <?php $__currentLoopData = $novel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3">
    <div class="card">
    <a href="<?php echo e(route('detail',$data)); ?>" style="text-decoration:none;color:black;" >
    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title"><?php echo e($data->judul); ?></h5>
    <p class="card-text"  style="height:250px;">Pengarang : <?php echo e($data -> pengarang); ?> <br> Penerbit : <?php echo e($data -> terbit); ?> <br> Pengarang : <?php echo e($data -> kode); ?> <br>sinposis : <?php echo e(str_limit($data -> deskripsi, $limit=100, $end='....')); ?> </p>  
  </div>
  <div class="card-footer">
  <form action="<?php echo e(route('peminjaman', $data)); ?>" method="post">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="nama" value="<?php echo e(Auth::user()->name); ?>">
  <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
  <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="<?php echo e($data->judul); ?>">
    <?php if(($data->status)==1): ?>
    <button type="submit" style="margin-left:25px;" class="btn btn-primary" onclick="confirm('Ingin Meminjam <?php echo e($data->judul); ?> ?')" value="submit">Borrow Now</button>
    <?php else: ?>
    <button type="submit" class="btn btn-warning" style="margin-left:30px;" >Borrowed</button>
    <?php endif; ?>
    <?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denda1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="denda" value="<?php echo e($denda1->denda); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $max; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $max1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="max" value="<?php echo e($max1->max); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </form> 
  </div>
  </a>
</div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>    
  </div>

<br>
<div class="container">
    <p><h1>Ensiklopedia</h1></p>
    <div class="row">
   
    <?php $__currentLoopData = $ensiklopedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3">
    <div class="card" >
    <a href="<?php echo e(route('detail',$data)); ?>" style="text-decoration:none;color:black;" >
    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title"><?php echo e($data->judul); ?></h5>
    <p class="card-text"  style="height:250px;">Pengarang : <?php echo e($data -> pengarang); ?> <br> Penerbit : <?php echo e($data -> terbit); ?> <br> Pengarang : <?php echo e($data -> kode); ?> <br>sinposis : <?php echo e(str_limit($data -> deskripsi, $limit=100, $end='....')); ?> </p>  
  </div>
  <div class="card-footer">
  <form action="<?php echo e(route('peminjaman', $data)); ?>" method="post">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="nama" value="<?php echo e(Auth::user()->name); ?>">
  <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
  <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="<?php echo e($data->judul); ?>">
    <?php if(($data->status)==1): ?>
    <button type="submit" style="margin-left:25px;" class="btn btn-primary" onclick="confirm('Ingin Meminjam <?php echo e($data->judul); ?> ?')" value="submit">Borrow Now</button>
    <?php else: ?>
    <button type="submit" class="btn btn-warning" style="margin-left:30px;" >Borrowed</button>
    <?php endif; ?>
    <?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denda1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="denda" value="<?php echo e($denda1->denda); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $max; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $max1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="max" value="<?php echo e($max1->max); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </form> 
  </div>
  </a>
</div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>    
 </div>


<br>



<div class="container">
    <p><h1>Horor</h1></p>
    <div class="row">
    <?php $__currentLoopData = $horor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
    <div class="col-md-3">
    <div class="card" >
    <a href="<?php echo e(route('detail',$data)); ?>" style="text-decoration:none;color:black;" >
    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title"><?php echo e($data->judul); ?></h5>
    <p class="card-text"  style="height:250px;">Pengarang : <?php echo e($data -> pengarang); ?> <br> Penerbit : <?php echo e($data -> terbit); ?> <br> Pengarang : <?php echo e($data -> kode); ?> <br>sinposis : <?php echo e(str_limit($data -> deskripsi, $limit=100, $end='....')); ?> </p>  
  </div>
  <div class="card-footer">
  <form action="<?php echo e(route('peminjaman', $data)); ?>" method="post">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="nama" value="<?php echo e(Auth::user()->name); ?>">
  <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
  <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="<?php echo e($data->judul); ?>">
    <?php if(($data->status)==1): ?>
    <button type="submit" style="margin-left:25px;" class="btn btn-primary" onclick="confirm('Ingin Meminjam <?php echo e($data->judul); ?> ?')" value="submit">Borrow Now</button>
    <?php else: ?>
    <button type="submit" class="btn btn-warning" style="margin-left:30px;" >Borrowed</button>
    <?php endif; ?>
    <?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denda1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="denda" value="<?php echo e($denda1->denda); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $max; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $max1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="max" value="<?php echo e($max1->max); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </form> 
  </div>
  </a>
</div>
</div>    

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 
</div>




<br>
    <div class="container">
    <p><h1>Kamus</h1></p>
    <div class="row">
    <?php $__currentLoopData = $kamus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
    <div class="col-md-3">
    <div class="card" >
    <a href="<?php echo e(route('detail',$data)); ?>" style="text-decoration:none;color:black;" >
    <img src="<?php echo e(asset('img/'.$data->gbr)); ?>" class="card-img-top" alt="..." style="height:200px;">
  <div class="card-body"  style="max-height:250px;">
    <h5 class="card-title"><?php echo e($data->judul); ?></h5>
    <p class="card-text"  style="height:250px;">Pengarang : <?php echo e($data -> pengarang); ?> <br> Penerbit : <?php echo e($data -> terbit); ?> <br> Pengarang : <?php echo e($data -> kode); ?> <br>sinposis : <?php echo e(str_limit($data -> deskripsi, $limit=100, $end='....')); ?> </p>  
  </div>
  <div class="card-footer">
  <form action="<?php echo e(route('peminjaman', $data)); ?>" method="post">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="nama" value="<?php echo e(Auth::user()->name); ?>">
  <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
  <input type="hidden" name="buku" value="<?php echo e($data->id_buku); ?>">
    <input type="hidden" name="value" value="0"  >
    <input type="hidden" name="judul" value="<?php echo e($data->judul); ?>">
    <?php if(($data->status)==1): ?>
    <button type="submit" style="margin-left:25px;"  onclick="confirm('Ingin Meminjam <?php echo e($data->judul); ?> ?')" class="btn btn-primary" value="submit">Borrow Now</button>
    <?php else: ?>
    <button type="submit" class="btn btn-warning" style="margin-left:30px;" >Borrowed</button>
    <?php endif; ?>
    
    <?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denda1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="denda" value="<?php echo e($denda1->denda); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $max; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $max1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="max" value="<?php echo e($max1->max); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form> 
  </div>
  </a>
</div>
</div>    
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
   </div>
</div>
<br><br>

<br><br>
<?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denda1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="denda" value="<?php echo e($denda1->denda); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $max; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $max1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" class="form-control" name="max" value="<?php echo e($max1->max); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="bg-dark p-1 text-white">
<p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis magnam, dignissimos qui doloribus eius in inventore omnis! Cum nulla inventore voluptatem impedit fugit. Libero cum quo sint, eligendi debitis dolor?</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/librarians/resources/views/loginu.blade.php ENDPATH**/ ?>