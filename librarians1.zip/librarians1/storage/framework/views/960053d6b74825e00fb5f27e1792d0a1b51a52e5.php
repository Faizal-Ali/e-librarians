<?php $__env->startSection('content'); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<div class="container">
<form action="<?php echo e(route('insert')); ?>" method="post" enctype="multipart/form-data">
<div class="card-head">
<h1>Tambah Buku</h1>
</div>

<div class="card-body">
<div class="form-group ">
<?php echo e(csrf_field ()); ?>

<div class="form-group row">
    <label for="judul" class="col-md-4 col-form-label text-md-right">Judul</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="judul" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="pengarang" class="col-md-4 col-form-label text-md-right">Pengarang</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="pengarang" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="terbit" class="col-md-4 col-form-label text-md-right">Penerbit</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="penerbit" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="terbit" class="col-md-4 col-form-label text-md-right">Tahun Terbit</label>
        <div class="col-lg-6">
              <input type="date" class="form-control" name="terbit" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="kategori" class="col-md-4 col-form-label text-md-right">Kategori</label>
    <div class="col-lg-6">
    <select name="myselect" class="form-control">
    <option value="     ">
  Pilih Kategori
    </option>
<?php $__currentLoopData = $ktg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($opg->kategori); ?>">
    <?php echo e($opg->kategori); ?>

    </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select></div>
</div>
<div class="form-group row">
    <label for="kode" class="col-md-4 col-form-label text-md-right">Kode</label>
        <div class="col-lg-6">
              <input type="text" class="form-control" name="kode" required autofocus>
        </div>
</div>
<div class="form-group row">
    <label for="deskripsi" class="col-md-4 col-form-label text-md-right">Sinopsis</label>
        <div class="col-lg-6">
              <textarea name="deskripsi" id="deskripsi" class="form-control" cols="30" rows="10"></textarea>
        </div>
</div>
<div class="form-group row">
    <label for="cover" class="col-md-4 col-form-label text-md-right">Upload Cover</label>
        <div class="col-lg-6">
              <input type="file" name="file"required>
              
        </div>
</div>

    <br>
    <div class="col-lg-6 ml-auto">
    <a href="/buku"class="btn btn-danger">Kembali</a>
    <input type="submit" class="btn btn-primary" value="submit">
    </div>
    
</form>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/perpustakaan3/resources/views/bukuTambah.blade.php ENDPATH**/ ?>