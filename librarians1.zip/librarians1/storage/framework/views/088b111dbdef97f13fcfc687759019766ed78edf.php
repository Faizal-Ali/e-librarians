<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div class="">
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm sticky-top">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto col-md-10">
                    <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('register')): ?>

                            <form class="mx-2 mr-auto d-inline w-100">
                             <div class="input-group">
                                <input type="search" class="form-control" placeholder="Cari Buku favoritmu">
                                      <span class="input-group-append">
                                          <button class="btn btn-outline-primary" type="button">GO</button>&nbsp
                                       </span>
                             </div>
                        </form>
                            <?php endif; ?>
                            <?php else: ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('anggota')): ?>
                            <li class="nav-item">
                            <a href="<?php echo e(route('pinjamku')); ?>" class="nav-link">Daftar Pinjaman</a>
                            </li>

                            <li class="nav-item">
                          
                            <a href="" class="nav-link">|   Denda : Rp. <?php echo e(Auth::user()->denda); ?></a>
                          
                            </li>
                            
                            <li class="nav-item">
                           <a href="" class="nav-link">Point : <?php echo e(Auth::user()->point); ?>   |</a>
                            
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                            <li class="nav-item">
                            <a href="<?php echo e(url('sirkulasi')); ?>" class="nav-link">Sirkulasi</a>
                            </li>
                            <li class="nav-item">
                            <a href="<?php echo e(url('waitting_list')); ?>" class="nav-link">Waitting List</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>Master Data<span class="caret"></span>
                                </a>
                    
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a href="<?php echo e(url('/buku')); ?>" class="dropdown-item">Buku</a>
                                    <a href="<?php echo e(url('/daftar_anggota')); ?>" class="dropdown-item">Anggota</a>
                                    

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('super')): ?>
                            <li class="nav-item">
                            <a href="<?php echo e(url('/sirkulasi')); ?>" class="nav-link">Sirkulasi</a>
                            </li>
                            <li><a href="" class="nav-link">Rekap</a></li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>Master Data<span class="caret"></span>
                                </a>
                    
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a href="<?php echo e(url('/buku')); ?>" class="dropdown-item">Buku</a>
                                    <a href="<?php echo e(url('/daftar_anggota')); ?>" class="dropdown-item">Anggota</a>                                    
                                    <a href="<?php echo e(url('/daftar_anggota')); ?>" class="dropdown-item">Admin</a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('register')): ?>
                            <?php endif; ?> &nbsp 
                            &nbsp
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-success">Sign Up</a> &nbsp
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary">Login</a>
                           
                        <?php else: ?>

                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>
                    
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    </div>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/perpustakaan/resources/views/layouts/app.blade.php ENDPATH**/ ?>