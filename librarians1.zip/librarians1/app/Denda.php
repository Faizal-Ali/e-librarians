<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Denda extends Model
{
    protected $primaryKey = 'id_denda';
    protected $table = "denda";
}
