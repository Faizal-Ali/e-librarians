<?php

namespace App\Http\Controllers;
use Carbon\Carbon;
use App\Kategori;
use App\Peminjaman;
use App\History;
use App\Denda;
use App\User;
use App\Buku;
use Illuminate\Http\Request;

class KategoriController extends Controller
{


    public function insert(Request $request){
    $kategori = new Kategori;
    $kategori->kategori = $request->kgi;
    $kategori->save();
    return redirect('kategori');
    }
    public function show(){
            $kgi = Kategori::all();
            return view('kategori', compact('kgi'));        
        }
        public function delete($data)
        {
            $kategori = Kategori::find($data);
            $kategori->delete();
            return redirect()->back();
        }
        public function rekap(){
            $now = Carbon::now();
            $month = Carbon::createFromFormat('Y-m-d H:i:s',$now)->month;
            $buku = Buku::all()->count();
            $kembali = History::whereMonth('tanggal_kembali','=',$month)->count();
            $anggota = User::where('level','=','1')->count();
            $admin = User::where('level','=','1')->count();
            $pinjam = Peminjaman::whereMonth('tanggal_pinjam','=',$month)->count();            
            $denda = History::select('denda')->whereMonth('tanggal_kembali','=',$month)->sum('denda');
            return view('rekap',compact('kembali','denda','pinjam','buku','anggota','admin'));
            }
}
