<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
class UserController extends Controller
{
    public function views(){
        $user = User::all();
        return view('anggota', compact('user'));
    }
    public function delete($id)
    {
        $user = User::find($id);
        $user->delete();
        return redirect()->back();
    }
    public function update(User $user)
    {
        return view ('anggotaUpdate',['data' => $user]);
    }
    public function edit($id, Request $request){
    $user = User::find($id);
    $user->name = $request->nama;
    $user->notelp = $request->notelp;
    $user->nim = $request->nim;
    $user->alamat = $request->alamat;
    $user->email = $request->email;
    $user->save();
    return redirect('/daftar_anggota');
    }
}