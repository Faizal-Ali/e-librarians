<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Auth;
use App\Tempo;
use App\Point;
use App\Buku;
use App\User;
use App\Peminjaman;
use App\Kategori;
use App\History;
use App\Denda;
use App\Max;
use File;
use Image;

class BukuController extends Controller
{
    public function detail(Buku $buku)
    {
        return view ('detail',['data' => $buku]);
    }
    public function login(){
        $baru = Buku::orderBy('created_at','desc')->paginate(4);
        $novel = Buku::where('kategori','=','novel')->paginate(4);
        $ensiklopedia = Buku::where('kategori','=','ensiklopedia')->paginate(4);
        $kamus = Buku::where('kategori','=','kamus')->paginate(4);
        $horor = Buku::where('kategori','=','horor')->paginate(4);
        $tbl = Buku::all()->groupBy('kategori');
        $max = Max::all();
        $denda = Denda::all();
       
        return view('loginu',compact('baru','horor','denda','novel','ensiklopedia','kamus','max','tbl'));
    }
    public function welcome(){
       
        $buku = Buku::paginate(4);
        $buku1 = Buku::limit(4)->get();
        return view('welcome',compact('buku','buku1'));
    }

    public function buku(){
        $buku = Buku::all();
        return view('buku', compact('buku'));
    }
    public function sirkulasi(){
        $buku = Peminjaman::all();
        $denda13 = Denda::all();
        $point13 = Point::all();
        return view('sirkulasi', compact('buku','denda13','point13'));
    }
    public function wlist(){
        $buku = Tempo::all();
        $max14 = Max::all();
        return view('waitting', compact('buku','max14'));
    }
    public function update(Buku $buku)
    {
        return view ('bukuUpdate',['data' => $buku]);
    }
    public function delete($id_buku)
    {
        $buku = Buku::find($id_buku);
        $buku->delete();
        return redirect()->back();
    }
    public function kategori(){
        $ktg = Kategori::all();
        return view('bukuTambah', compact('ktg'));
    }
    public function insert(Request $request){
            $cover = $request->file('file');
        $buku = new Buku;
    $buku->gbr = $cover->GetClientOriginalName();
    $buku->judul = $request->judul;
    $buku->pengarang = $request->pengarang;
    $buku->penerbit = $request->penerbit;
    $buku->terbit = $request->terbit;
    $buku->kategori = $request->myselect;
    $buku->kode = $request->kode;
    $buku->deskripsi = $request->deskripsi;
    $buku->save();
    $cover->move('img/', $cover->getClientOriginalName());
    return redirect('buku');
    }
    public function edit($id_buku, Request $request){
        $this ->validate($request, [
            'judul' => 'required',
            'pengarang' => 'required',
            'terbit' => 'required',
            'kategori' => 'required',
            'kode' => 'required' 
        ]);
    $buku = Buku::find($id_buku);
    $buku->judul = $request->judul;
    $buku->pengarang = $request->pengarang;
    $buku->terbit = $request->terbit;
    $buku->kategori = $request->kategori;
    $buku->kode = $request->kode;
    $buku->save();
    return redirect('buku');
    }
   public function view()
   {
        return view('admin');
   }


   public function pinjam($data, Request $request){
    $borrow_limit = Auth::user()->pinjam;
    if ($borrow_limit != 0) {

$user = Auth::user()->id;
    $buku = Buku::find($data);
 
$buku->status = $request->value;
$buku->save();

// get the current time
$current = Carbon::now();

// add 30 days to the current time
$ululu = $request->max;
$trialExpires = $current->addDays($ululu);


$pinjam = new Tempo;
$pinjam->id_user = $request->id;
$pinjam->nama_user = $request->nama;
$pinjam->id_buku = $request->buku;
$pinjam->judul = $request->judul;
$pinjam->max_kembali = $trialExpires;
$pinjam->save();

User::where('id','=',$user)->decrement('pinjam',1);
return redirect()->back();}else{
    return redirect()->back()->with(['message' => 'Buku Sedang Dipinjam']);
}
}

/////////////////////////////////////

public function ambil($data, Request $request)
{

    $kembali = Peminjaman::find($data);
    $date = Carbon::now();
    $jthtmp = $request->jth;
    $max_date = $date->addDays($jthtmp);
$tgl_kembali = $request->kembali;


$kembali = new Peminjaman;
$kembali->id_user = $request->id;
$kembali->nama_user = $request->nama;

$kembali->judul = $request->judul_buku;
$kembali->kode_buku = $request->buku;
$kembali->id_buku = $request->buku;
$kembali->tanggal_pinjam = $request->pinjam;
$kembali->max_kembali = $max_date;
$kembali->save();
//count denda
// $tgl_kembali > $max_tgl (rumus)


  $delete = Tempo::find($data);
  $delete->delete();
  return redirect()->back();
}


/////////////////////////////////////////////
public function Pengembalian($data, Request $request)
{

    $kembali = Peminjaman::find($data);

$tgl_kembali = $request->kembali;
$max_tgl = $request->max_kembali;
$dendax = $request->dendax;
$pointx = $request->pointx;
$denda = 0;
$tgl_kembali = Carbon::now();
$hasil = $tgl_kembali->diffInDays($max_tgl);

$kembali = new History;
$kembali->id_user = $request->id;
$kembali->nama = $request->nama;
$kembali->denda = $denda;
$kembali->judul = $request->judul_buku;
$kembali->kode_buku = $request->buku;
$kembali->tgl_peminjaman = $request->pinjam;
$kembali->tanggal_kembali = $tgl_kembali;
$kembali->save();
//count denda

// $tgl_kembali > $max_tgl (rumus
if ($tgl_kembali > $max_tgl) {
  $denda = $hasil*$dendax;
}
$user = $request->id;
  $limit = User::where('id','=',$user)->increment('pinjam',1);
  $user_denda = User::where('id','=',$user)->increment('denda',$denda);
  $user_point= User::where('id','=',$user)->increment('point',$pointx);
$buku = $request->buku;
  $status = Buku::where('id_buku','=',$buku)->first();
  $status['status'] = 1;
  $status->save();

  $delete = Peminjaman::find($data);
  $delete->delete();
  
  if ($denda == 0) {
    return redirect()->back()->with('message', 'Pengambalian Buku Tepat Waktu');
  } else {
    return redirect()->back()->with('message', "Pengembalian Buku Terlambat denda = Rp.{$denda}");
  }
}
public function pinjamku(){
$user = Auth::user()->name ;
$buku = Peminjaman:: where('id_user','=',$user)->get();
$buku1 = Tempo:: where('id_user','=',$user)->get();
return view('pinjamku',compact('buku','buku1'));
    
}
public function redeem($data)
{
    $tukar['point'] = User::find($data);
    return view ('redeem', $tukar);
}
public function tukar($data, Request $request)
{
    $tukar = $request->tkr;
    $user_denda = User::where('id','=',$data)->decrement('point',$tukar);
    return redirect('daftar_anggota');
}
public function denda($data)
{
    $tukar['denda'] = User::find($data);
    return view ('denda', $tukar);
}
public function tax($data,Request $request)
{
    $bayar = $request->bayar;
    $denda = $request->denda;
    if($bayar>0){
    $user_denda = User::where('id','=',$data)->decrement('denda',$bayar);
    return redirect()->back();
    }else{
        $user_denda = User::where('id','=',$data)->decrement('denda',$denda);
        return redirect('daftar_anggota');
    }
}
public function edit_denda()
{
    $x['denda'] = Denda::all();
    return view ('dendax', $x);
}
public function update_denda($data,Request $request)
{
    $denda = Denda::find($data);
    $denda->dendau = $request->dendab;
    $denda->save();
    return redirect('edit_denda');

}
public function edit_max()
{
    $m['max1'] = Max::all();
    return view ('max', $m);
}
public function update_max($data,Request $request)
{
    $max = Max::find($data);
    $max->max = $request->dendab;
    $max->save();
    return redirect()->back();

}
public function edit_point()
{
    $p['point'] = Point::all();
    return view ('point', $p);
}
public function update_point($data,Request $request)
{
    $max = Point::find($data);
    $max->point = $request->pointb;
    $max->save();
    return redirect()->back();
}
public function search(Request $request){
    
}

}