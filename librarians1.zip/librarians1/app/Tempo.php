<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tempo extends Model
{
    protected $primaryKey = 'id_tempo';
    protected $table = "tempo";
}
