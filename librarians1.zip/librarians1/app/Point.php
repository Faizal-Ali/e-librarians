<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Point extends Model
{
    protected $primaryKey = 'id_point';
    protected $table = "point";
}
