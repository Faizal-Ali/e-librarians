<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Max extends Model
{
    public $timestamps = false;
    protected $primaryKey = 'id_max';
    protected $table = "max";
}
